package com.example.doomwaves;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    private WebView web;
    private SoundPool pool;
    private HandlerThread sndThread;
    private Handler sndH;
    private final ConcurrentHashMap<String, Integer> ids = new ConcurrentHashMap<String, Integer>();
    private final ConcurrentHashMap<Integer, Boolean> ready = new ConcurrentHashMap<Integer, Boolean>();

    private static final int SR = 22050;
    private static final String[] KEYS = {"shot0", "shot1", "shot2", "rl1", "rl2", "hurt", "die", "fb", "wave",
            "hit", "aim", "claw", "roar", "clear", "over", "coin", "swap", "beat"};

    // Мост JS <-> Java: сохранение, настройки и звук
    public class Bridge {
        @JavascriptInterface
        public void save(String s) {
            getSharedPreferences("doom", Context.MODE_PRIVATE).edit().putString("save", s).apply();
        }
        @JavascriptInterface
        public String load() {
            return getSharedPreferences("doom", Context.MODE_PRIVATE).getString("save", "");
        }
        @JavascriptInterface
        public void saveCfg(String s) {
            getSharedPreferences("doom", Context.MODE_PRIVATE).edit().putString("cfg", s).apply();
        }
        @JavascriptInterface
        public String loadCfg() {
            return getSharedPreferences("doom", Context.MODE_PRIVATE).getString("cfg", "");
        }
        @JavascriptInterface
        public boolean sndOk() {
            return pool != null;
        }
        @JavascriptInterface
        public void snd(String k) {
            playAsync(new String[]{k});
        }
        @JavascriptInterface
        public void sndb(String list) {
            playAsync(list.split(","));
        }
        @JavascriptInterface
        public String mem() {
            long nat = Debug.getNativeHeapAllocatedSize() >> 20;
            Runtime rt = Runtime.getRuntime();
            long jv = (rt.totalMemory() - rt.freeMemory()) >> 20;
            return nat + "/" + jv + "M";
        }
    }

    private void playAsync(final String[] keys) {
        if (sndH == null) return;
        sndH.post(new Runnable() {
            public void run() {
                for (int i = 0; i < keys.length; i++) {
                    Integer id = ids.get(keys[i]);
                    if (id != null && pool != null && ready.containsKey(id)) {
                        pool.play(id, 1f, 1f, 1, 0, 1f);
                    }
                }
            }
        });
    }

    // ---------- синтез звуков (всё генерируется в коде, файлов нет) ----------
    private static void tone(float[] b, double f1, double f2, double dur, int type, double vol) {
        int n = Math.min(b.length, (int) (SR * dur));
        double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            double f = f1 * Math.pow(f2 / f1, t / dur);
            ph += 2 * Math.PI * f / SR;
            double env = vol * Math.pow(0.001 / vol, t / dur);
            double fr = (ph / (2 * Math.PI)) % 1.0;
            double s;
            switch (type) {
                case 0: s = Math.sin(ph); break;
                case 1: s = fr < 0.5 ? 1 : -1; break;
                case 2: s = 2 * fr - 1; break;
                default: s = 2 * Math.abs(2 * fr - 1) - 1; break;
            }
            b[i] += (float) (s * env);
        }
    }

    private static void noise(float[] b, double dur, double vol, double lp) {
        int n = Math.min(b.length, (int) (SR * dur));
        double a = 2 * Math.PI * lp / (SR + 2 * Math.PI * lp);
        double y = 0;
        Random r = new Random(7);
        for (int i = 0; i < n; i++) {
            double t = i / (double) SR;
            y += a * ((r.nextDouble() * 2 - 1) - y);
            double env = vol * Math.pow(0.001 / vol, t / dur);
            b[i] += (float) (y * env * 2.2);
        }
    }

    private static float[] synth(String k) {
        float[] b;
        if (k.equals("shot0")) { b = new float[SR * 15 / 100]; noise(b, .12, .5, 3000); tone(b, 300, 60, .1, 1, .3); }
        else if (k.equals("shot1")) { b = new float[SR * 40 / 100]; noise(b, .35, .9, 1800); tone(b, 120, 40, .25, 2, .4); }
        else if (k.equals("shot2")) { b = new float[SR * 12 / 100]; noise(b, .09, .5, 4000); tone(b, 200, 70, .07, 1, .25); }
        else if (k.equals("rl1")) { b = new float[SR * 8 / 100]; tone(b, 900, 500, .06, 1, .15); }
        else if (k.equals("rl2")) { b = new float[SR * 10 / 100]; tone(b, 400, 900, .07, 1, .2); }
        else if (k.equals("hurt")) { b = new float[SR * 30 / 100]; tone(b, 160, 50, .25, 2, .4); }
        else if (k.equals("die")) { b = new float[SR * 35 / 100]; noise(b, .3, .5, 900); tone(b, 220, 40, .3, 2, .25); }
        else if (k.equals("fb")) { b = new float[SR * 30 / 100]; tone(b, 700, 200, .25, 0, .25); }
        else if (k.equals("wave")) { b = new float[SR * 65 / 100]; tone(b, 110, 220, .6, 2, .25); }
        else if (k.equals("hit")) { b = new float[SR * 6 / 100]; tone(b, 500, 200, .04, 1, .12); }
        else if (k.equals("aim")) { b = new float[SR * 12 / 100]; tone(b, 1200, 1100, .09, 0, .12); }
        else if (k.equals("claw")) { b = new float[SR * 13 / 100]; noise(b, .1, .35, 2500); }
        else if (k.equals("roar")) { b = new float[SR * 70 / 100]; tone(b, 90, 40, .7, 2, .35); noise(b, .6, .3, 500); }
        else if (k.equals("clear")) { b = new float[SR * 35 / 100]; tone(b, 330, 660, .3, 3, .3); }
        else if (k.equals("over")) { b = new float[SR * 105 / 100]; tone(b, 200, 35, 1, 2, .4); }
        else if (k.equals("coin")) { b = new float[SR * 13 / 100]; tone(b, 900, 1500, .1, 1, .15); }
        else if (k.equals("swap")) { b = new float[SR * 8 / 100]; tone(b, 250, 180, .05, 1, .15); }
        else { b = new float[SR * 15 / 100]; tone(b, 70, 40, .12, 0, .5); }
        return b;
    }

    private static void writeWav(File f, float[] d) throws Exception {
        int n = d.length * 2;
        byte[] o = new byte[44 + n];
        putStr(o, 0, "RIFF"); putInt(o, 4, 36 + n); putStr(o, 8, "WAVE"); putStr(o, 12, "fmt ");
        putInt(o, 16, 16); o[20] = 1; o[22] = 1; putInt(o, 24, SR); putInt(o, 28, SR * 2); o[32] = 2; o[34] = 16;
        putStr(o, 36, "data"); putInt(o, 40, n);
        for (int i = 0; i < d.length; i++) {
            int v = (int) (Math.max(-1f, Math.min(1f, d[i] * 0.9f)) * 32767);
            o[44 + i * 2] = (byte) (v & 255);
            o[45 + i * 2] = (byte) ((v >> 8) & 255);
        }
        FileOutputStream out = new FileOutputStream(f);
        out.write(o);
        out.close();
    }
    private static void putStr(byte[] o, int p, String s) { for (int i = 0; i < s.length(); i++) o[p + i] = (byte) s.charAt(i); }
    private static void putInt(byte[] o, int p, int v) { o[p] = (byte) v; o[p + 1] = (byte) (v >> 8); o[p + 2] = (byte) (v >> 16); o[p + 3] = (byte) (v >> 24); }

    private void initSound() {
        sndThread = new HandlerThread("snd");
        sndThread.start();
        sndH = new Handler(sndThread.getLooper());
        try {
            pool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
            pool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                public void onLoadComplete(SoundPool sp, int id, int status) {
                    if (status == 0) ready.put(id, Boolean.TRUE);
                }
            });
        } catch (Throwable t) {
            pool = null;
            return;
        }
        new Thread(new Runnable() {
            public void run() {
                try {
                    for (int i = 0; i < KEYS.length; i++) {
                        File f = new File(getCacheDir(), "s_" + KEYS[i] + ".wav");
                        writeWav(f, synth(KEYS[i]));
                        ids.put(KEYS[i], pool.load(f.getAbsolutePath(), 1));
                    }
                } catch (Throwable t) { /* без звука, игра работает дальше */ }
            }
        }).start();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        initSound();
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Native");
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) { return true; }
        });
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setBackgroundColor(0xFF000000);
        setContentView(web);
        String html;
        try {
            InputStream in = getAssets().open("index.html");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            html = new String(out.toByteArray(), "UTF-8");
        } catch (Exception e) {
            html = "<body style='background:#fff;color:#000'><h3>Ошибка загрузки игры</h3>" + e + "</body>";
        }
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override protected void onPause() {
        super.onPause();
        web.loadUrl("javascript:saveNow();if(window.autoPause)autoPause()");
        web.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        web.onResume();
        web.loadUrl("javascript:if(window.autoPause)autoPause()");
    }
    @Override protected void onDestroy() {
        super.onDestroy();
        if (pool != null) pool.release();
        if (sndThread != null) sndThread.quit();
    }
}
